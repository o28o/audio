The files on this website are all made available to you thanks to the generosity of dozens of authors, translators, publishers, and transcribers, all of whom contributed their efforts with the explicit understanding that the fruits of their labors would be given away free of charge, as an expression of dana. It is in this same spirit that you are invited to download these files to your computer, print them out, share them with your friends, copy them to your own website, translate them into other languages, convert them into other formats, and redistribute them electronically - **provided that you do not charge any money for them**. 

There are several kinds of copyright licenses attached to the pages of Access to Insight. The majority of texts are licensed under the Creative Commons Attribution-NonCommercial 4.0 International License. Some, however, are subject to more restrictive licenses; others, to more liberal ones. You'll find details about the license at the bottom of each rendered page.


The portions of each page that are subject to copyright are so demarcated in the HTML markup, thus:

>&lt;div id='COPYRIGHTED\_TEXT\_CHUNK'&gt;&lt;!-- BEGIN COPYRIGHTED TEXT CHUNK --&gt;
>
>....
>
>&lt;/div&gt;&lt;!-- #COPYRIGHTED\_TEXT\_CHUNK (END OF COPYRIGHTED TEXT CHUNK) --&gt;

The HTML markup itself in these pages is not subject to copyright.	

For more info about "repackaging" these texts, see the README.


> -- jtb, 20131203